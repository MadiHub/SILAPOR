

<?php $__env->startSection('title', 'Dashboard Pemda'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Dashboard</h1>

    
    <div class="dashboard-cards" style="margin-bottom: 30px;">

        <div class="card" style="border-left: 5px solid var(--primary-color);">
            <h3 style="font-size:0.95em; color:#777; text-transform:uppercase;">Total Laporan</h3>
            <p style="font-size:2em; font-weight:700; color:var(--text-dark);"><?php echo e($totalReports); ?></p>
        </div>

        <div class="card" style="border-left: 5px solid #f59e0b;">
            <h3 style="font-size:0.95em; color:#777; text-transform:uppercase;">Aktif</h3>
            <p style="font-size:2em; font-weight:700; color:#f59e0b;"><?php echo e($active); ?></p>
        </div>

        <div class="card" style="border-left: 5px solid #3b82f6;">
            <h3 style="font-size:0.95em; color:#777; text-transform:uppercase;">Diproses</h3>
            <p style="font-size:2em; font-weight:700; color:#3b82f6;"><?php echo e($process); ?></p>
        </div>

        <div class="card" style="border-left: 5px solid #10b981;">
            <h3 style="font-size:0.95em; color:#777; text-transform:uppercase;">Selesai</h3>
            <p style="font-size:2em; font-weight:700; color:#10b981;"><?php echo e($done); ?></p>
        </div>

        <div class="card" style="border-left: 5px solid #ef4444;">
            <h3 style="font-size:0.95em; color:#777; text-transform:uppercase;">Ditolak</h3>
            <p style="font-size:2em; font-weight:700; color:#ef4444;"><?php echo e($rejected); ?></p>
        </div>

    </div>

    
    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:25px; margin-bottom:30px;">

        <div class="card">
            <h3>Tren Laporan Masuk</h3>
            <canvas id="chartReportsPerDay" height="120"></canvas>
        </div>

        <div class="card">
            <h3>Top Kategori</h3>
            <canvas id="chartTopCategories" height="160"></canvas>
        </div>

    </div>

    
    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:25px;">

        
        <div class="card">
            <h3>Laporan Terbaru</h3>

            <?php if($latestReports->isEmpty()): ?>
                <p style="color:#777;">Belum ada laporan masuk.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table style="width:100%; border-collapse:collapse; font-size:0.9em;">
                        <thead>
                            <tr style="text-align:left; border-bottom:2px solid var(--background-light);">
                                <th style="padding:10px 8px;">Foto</th>
                                <th style="padding:10px 8px;">Judul</th>
                                <th style="padding:10px 8px;">Kategori</th>
                                <th style="padding:10px 8px;">Status</th>
                                <th style="padding:10px 8px;">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $latestReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $statusColor = match($report->status) {
                                        'active' => '#f59e0b',
                                        'process' => '#3b82f6',
                                        'done' => '#10b981',
                                        'rejected' => '#ef4444',
                                        default => '#777',
                                    };
                                    $firstImage = $report->images->first();
                                ?>
                                <tr style="border-bottom:1px solid var(--background-light);">
                                    <td style="padding:10px 8px;">
                                        <?php if($firstImage): ?>
                                            <img src="<?php echo e(asset('storage/' . $firstImage->image_url)); ?>"
                                                 style="width:48px; height:48px; object-fit:cover; border-radius:6px;">
                                        <?php else: ?>
                                            <div style="width:48px; height:48px; border-radius:6px; background:var(--background-light); display:flex; align-items:center; justify-content:center; color:#aaa;">
                                                <i class="fas fa-image"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:10px 8px;">
                                        <a href="<?php echo e(route('pemda.reports.show', $report->id)); ?>" style="color:var(--text-dark); text-decoration:none; font-weight:500;">
                                            <?php echo e($report->title); ?>

                                        </a>
                                        <div style="font-size:0.8em; color:#999;"><?php echo e($report->address); ?></div>
                                    </td>
                                    <td style="padding:10px 8px;"><?php echo e($report->category->name ?? '-'); ?></td>
                                    <td style="padding:10px 8px;">
                                        <span style="background:<?php echo e($statusColor); ?>1A; color:<?php echo e($statusColor); ?>; padding:4px 10px; border-radius:20px; font-size:0.8em; font-weight:600; text-transform:capitalize;">
                                            <?php echo e($report->status); ?>

                                        </span>
                                    </td>
                                    <td style="padding:10px 8px; color:#777;"><?php echo e($report->created_at->format('d M Y')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="card">
            <h3>Laporan Prioritas</h3>
            <p style="font-size:0.8em; color:#999; margin-top:-10px; margin-bottom:15px;">Diurutkan berdasarkan jumlah vote</p>

            <?php if($priorityReports->isEmpty()): ?>
                <p style="color:#777;">Belum ada laporan.</p>
            <?php else: ?>
                <ul style="list-style:none;">
                    <?php $__currentLoopData = $priorityReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="display:flex; justify-content:space-between; align-items:center; padding:12px 0; border-bottom:1px solid var(--background-light);">
                            <div>
                                <a href="<?php echo e(route('pemda.reports.show', $report->id)); ?>" style="color:var(--text-dark); text-decoration:none; font-weight:500; font-size:0.9em;">
                                    <?php echo e($report->title); ?>

                                </a>
                                <div style="font-size:0.8em; color:#999;"><?php echo e($report->category->name ?? '-'); ?></div>
                            </div>
                            <span style="background:var(--primary-color); color:#fff; padding:4px 10px; border-radius:20px; font-size:0.8em; font-weight:600; white-space:nowrap;">
                                <i class="fas fa-arrow-up"></i> <?php echo e($report->votes_count); ?>

                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <script>
        // ===== DATA DARI CONTROLLER =====
        const chartReportsRaw = <?php echo json_encode($chartReports, 15, 512) ?>;
        const topCategoriesRaw = <?php echo json_encode($topCategories, 15, 512) ?>;

        // ===== LINE CHART: LAPORAN PER HARI =====
        const reportLabels = chartReportsRaw.map(item => {
            const d = new Date(item.date);
            return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
        });
        const reportTotals = chartReportsRaw.map(item => item.total);

        new Chart(document.getElementById('chartReportsPerDay'), {
            type: 'line',
            data: {
                labels: reportLabels,
                datasets: [{
                    label: 'Laporan Masuk',
                    data: reportTotals,
                    borderColor: '#AA0E0E',
                    backgroundColor: 'rgba(170, 14, 14, 0.1)',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3,
                    pointBackgroundColor: '#AA0E0E',
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { precision: 0 }
                    }
                }
            }
        });

        // ===== PIE CHART: TOP KATEGORI =====
        const categoryLabels = topCategoriesRaw.map(item => item.name);
        const categoryCounts = topCategoriesRaw.map(item => item.reports_count);
        const categoryColors = ['#AA0E0E', '#f59e0b', '#3b82f6', '#10b981', '#8b5cf6'];

        new Chart(document.getElementById('chartTopCategories'), {
            type: 'doughnut',
            data: {
                labels: categoryLabels,
                datasets: [{
                    data: categoryCounts,
                    backgroundColor: categoryColors,
                    borderWidth: 0,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12, font: { size: 11 } }
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.PemdaLayout.base_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\development\silapor\resources\views/Pemda/dashboard.blade.php ENDPATH**/ ?>