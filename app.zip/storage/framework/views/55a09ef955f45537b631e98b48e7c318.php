

<?php $__env->startSection('title', 'Edit Pengguna – ' . $user->name); ?>

<?php $__env->startSection('content'); ?>


<div style="font-size:0.85em; color:#999; margin-bottom:16px;">
    <a href="<?php echo e(route('admin.users.index')); ?>" style="color:var(--primary-color); text-decoration:none;">Pengguna</a>
    <span style="margin:0 6px;">/</span>
    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" style="color:var(--primary-color); text-decoration:none;"><?php echo e($user->name); ?></a>
    <span style="margin:0 6px;">/</span> Edit
</div>

<h1 style="margin:0 0 24px;">Edit Pengguna</h1>

<form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <div style="display:grid; grid-template-columns: 1fr 2fr; gap:24px; align-items:start;">

        
        <div class="card" style="text-align:center;">
            <div style="margin-bottom:16px;">
                <img id="avatar-preview"
                     src="<?php echo e($user->avatar_url); ?>"
                     style="width:100px; height:100px; border-radius:50%; object-fit:cover; border:3px solid var(--background-light); margin:0 auto 14px; display:block;">
            </div>
            <label for="avatar"
                   style="display:inline-block; background:var(--background-light); color:var(--text-dark); padding:8px 16px; border-radius:6px; cursor:pointer; font-size:0.85em; font-weight:600;">
                <i class="fas fa-upload"></i> Ganti Foto
            </label>
            <input type="file" id="avatar" name="avatar" accept="image/*"
                   style="display:none;"
                   onchange="previewAvatar(this)">
            <p style="font-size:0.75em; color:#aaa; margin:8px 0 0;">Biarkan kosong untuk tidak mengubah foto</p>
            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color:#ef4444; font-size:0.8em; margin-top:6px;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div style="border-top:1px solid var(--background-light); margin:16px 0;"></div>

            <div style="text-align:left; font-size:0.82em; color:#999;">
                <p style="margin:0 0 6px;"><i class="fas fa-id-badge" style="width:14px;"></i> ID: #<?php echo e($user->id); ?></p>
                <p style="margin:0 0 6px;"><i class="fas fa-calendar-plus" style="width:14px;"></i> Bergabung: <?php echo e($user->created_at->format('d M Y')); ?></p>
                <p style="margin:0;"><i class="fas fa-clock" style="width:14px;"></i> Login terakhir:
                    <?php echo e($user->last_login_at ? $user->last_login_at->diffForHumans() : 'Belum pernah'); ?>

                </p>
            </div>
        </div>

        
        <div style="display:flex; flex-direction:column; gap:20px;">

            
            <div class="card">
                <h3 style="margin:0 0 16px; font-size:1em;">Identitas</h3>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">

                    <div>
                        <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                            Nama Lengkap <span style="color:#ef4444;">*</span>
                        </label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required
                               style="width:100%; padding:9px 12px; border:1px solid <?php echo e($errors->has('name') ? '#ef4444' : 'var(--background-light)'); ?>; border-radius:6px; font-size:0.9em; box-sizing:border-box;">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:#ef4444;font-size:0.78em;margin:4px 0 0;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                            Nomor HP
                        </label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>"
                               placeholder="08xxxxxxxxxx"
                               style="width:100%; padding:9px 12px; border:1px solid var(--background-light); border-radius:6px; font-size:0.9em; box-sizing:border-box;">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:#ef4444;font-size:0.78em;margin:4px 0 0;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                            Email <span style="color:#ef4444;">*</span>
                        </label>
                        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required
                               style="width:100%; padding:9px 12px; border:1px solid <?php echo e($errors->has('email') ? '#ef4444' : 'var(--background-light)'); ?>; border-radius:6px; font-size:0.9em; box-sizing:border-box;">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:#ef4444;font-size:0.78em;margin:4px 0 0;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                            Password Baru
                        </label>
                        <div style="position:relative;">
                            <input type="password" name="password" id="password"
                                   placeholder="Kosongkan jika tidak diubah"
                                   style="width:100%; padding:9px 38px 9px 12px; border:1px solid <?php echo e($errors->has('password') ? '#ef4444' : 'var(--background-light)'); ?>; border-radius:6px; font-size:0.9em; box-sizing:border-box;">
                            <button type="button" onclick="togglePassword('password')"
                                    style="position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; color:#aaa; cursor:pointer; font-size:0.85em;">
                                <i class="fas fa-eye" id="password-icon"></i>
                            </button>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p style="color:#ef4444;font-size:0.78em;margin:4px 0 0;"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
            </div>

            
            <div class="card">
                <h3 style="margin:0 0 16px; font-size:1em;">Role & Status</h3>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">

                    <div>
                        <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                            Role <span style="color:#ef4444;">*</span>
                        </label>
                        <select name="role" required
                                style="width:100%; padding:9px 12px; border:1px solid var(--background-light); border-radius:6px; font-size:0.9em;">
                            <option value="warga"  <?php echo e(old('role',$user->role)=='warga'  ? 'selected':''); ?>>Warga</option>
                            <option value="pemda"  <?php echo e(old('role',$user->role)=='pemda'  ? 'selected':''); ?>>Pemda</option>
                            <option value="admin"  <?php echo e(old('role',$user->role)=='admin'  ? 'selected':''); ?>>Admin</option>
                        </select>
                    </div>

                    <div>
                        <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                            Status <span style="color:#ef4444;">*</span>
                        </label>
                        <select name="status" required
                                style="width:100%; padding:9px 12px; border:1px solid var(--background-light); border-radius:6px; font-size:0.9em;">
                            <option value="active"   <?php echo e(old('status',$user->status)=='active'   ? 'selected':''); ?>>Aktif</option>
                            <option value="inactive" <?php echo e(old('status',$user->status)=='inactive' ? 'selected':''); ?>>Suspended</option>
                            <option value="banned"   <?php echo e(old('status',$user->status)=='banned'   ? 'selected':''); ?>>Banned</option>
                        </select>
                    </div>

                </div>
            </div>

            
            <div class="card">
                <h3 style="margin:0 0 6px; font-size:1em;">Dinas</h3>
                <p style="font-size:0.82em; color:#aaa; margin:0 0 14px;">Centang dinas yang dikelola pengguna ini.</p>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; max-height:200px; overflow-y:auto; padding:2px;">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label style="display:flex; align-items:center; gap:8px; padding:8px 10px; border:1px solid var(--background-light); border-radius:6px; cursor:pointer; font-size:0.88em;"
                               onmouseover="this.style.background='var(--background-light)'"
                               onmouseout="this.style.background='#fff'">
                            <input type="checkbox" name="department_ids[]" value="<?php echo e($dept->id); ?>"
                                   <?php echo e($user->departments->contains($dept->id) ? 'checked' : ''); ?>

                                   style="accent-color:var(--primary-color);">
                            <span>
                                <strong><?php echo e($dept->code); ?></strong> – <?php echo e($dept->name); ?>

                            </span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div style="display:flex; gap:12px; justify-content:flex-end;">
                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>"
                   style="padding:10px 20px; border:1px solid var(--background-light); border-radius:8px; text-decoration:none; color:var(--text-dark); font-size:0.9em;">
                    Batal
                </a>
                <button type="submit"
                        style="background:var(--primary-color); color:#fff; border:none; padding:10px 24px; border-radius:8px; cursor:pointer; font-size:0.9em; font-weight:600;">
                    <i class="fas fa-save"></i> Perbarui Data
                </button>
            </div>

        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function previewAvatar(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = e => document.getElementById('avatar-preview').src = e.target.result;
            reader.readAsDataURL(input.files[0]);
        }
    }

    function togglePassword(id) {
        const input = document.getElementById(id);
        const icon  = document.getElementById(id + '-icon');
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash';
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye';
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.AdminLayout.base_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\development\silapor\resources\views/Admin/Users/edit.blade.php ENDPATH**/ ?>