

<?php $__env->startSection('title', 'Edit Kategori – ' . $category->name); ?>

<?php $__env->startSection('content'); ?>


<div style="font-size:0.85em; color:#999; margin-bottom:16px;">
    <a href="<?php echo e(route('admin.categories.index')); ?>" style="color:var(--primary-color); text-decoration:none;">Kategori</a>
    <span style="margin:0 6px;">/</span>
    <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>" style="color:var(--primary-color); text-decoration:none;"><?php echo e($category->name); ?></a>
    <span style="margin:0 6px;">/</span> Edit
</div>

<h1 style="margin:0 0 24px;">Edit Kategori</h1>

<div style="max-width:680px;">
    <form method="POST" action="<?php echo e(route('admin.categories.update', $category->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="card" style="margin-bottom:20px;">
            <h3 style="margin:0 0 18px; font-size:1em;">Informasi Kategori</h3>

            
            <div style="margin-bottom:16px;">
                <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                    Nama Kategori <span style="color:#ef4444;">*</span>
                </label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $category->name)); ?>" required
                       style="width:100%; padding:10px 12px; border:1px solid <?php echo e($errors->has('name') ? '#ef4444' : 'var(--background-light)'); ?>; border-radius:6px; font-size:0.9em; box-sizing:border-box;">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color:#ef4444; font-size:0.8em; margin:4px 0 0;"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div style="margin-bottom:16px;">
                <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                    Dinas Penanggungjawab <span style="color:#ef4444;">*</span>
                </label>
                <select name="department_id" id="department_id" required
                        style="width:100%; padding:10px 12px; border:1px solid <?php echo e($errors->has('department_id') ? '#ef4444' : 'var(--background-light)'); ?>; border-radius:6px; font-size:0.9em;">
                    <option value="">-- Pilih Dinas --</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dept->id); ?>"
                            <?php echo e(old('department_id', $category->department_id) == $dept->id ? 'selected' : ''); ?>>
                            <?php echo e($dept->name); ?> (<?php echo e($dept->code); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($category->department_id !== (int) old('department_id', $category->department_id)): ?>
                    <p style="font-size:0.78em; color:#f59e0b; margin:4px 0 0;">
                        <i class="fas fa-exclamation-triangle"></i>
                        Mengubah dinas di sini sama dengan melakukan remap — laporan terkait akan ikut berpindah dinas.
                    </p>
                <?php else: ?>
                    <p style="font-size:0.78em; color:#aaa; margin:4px 0 0;">
                        Untuk memindahkan ke dinas lain, gunakan fitur <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>" style="color:var(--primary-color);">Pindah Dinas</a> di halaman detail.
                    </p>
                <?php endif; ?>
                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color:#ef4444; font-size:0.8em; margin:4px 0 0;"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label style="font-size:0.85em; color:#555; display:block; margin-bottom:5px; font-weight:500;">
                    Deskripsi
                </label>
                <textarea name="description" rows="4"
                          style="width:100%; padding:10px 12px; border:1px solid var(--background-light); border-radius:6px; font-size:0.9em; box-sizing:border-box; resize:vertical; line-height:1.5;"><?php echo e(old('description', $category->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color:#ef4444; font-size:0.8em; margin:4px 0 0;"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="card" style="margin-bottom:20px; background:var(--background-light);">
            <p style="font-size:0.78em; color:#aaa; text-transform:uppercase; font-weight:600; margin:0 0 12px;">Preview</p>
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="background:#f3f4f6; color:#555; padding:4px 12px; border-radius:20px; font-size:0.82em; font-weight:600;">
                    <i class="fas fa-tag"></i> Kategori
                </span>
                <span id="preview-dept-badge"
                      style="background:var(--primary-color); color:#fff; padding:4px 12px; border-radius:20px; font-size:0.82em; font-weight:600;">
                    <?php echo e($category->department->code ?? ''); ?>

                </span>
                <span id="preview-name" style="font-weight:600; color:var(--text-dark);"><?php echo e($category->name); ?></span>
            </div>
        </div>

        
        <div class="card" style="margin-bottom:20px; font-size:0.85em; color:#777;">
            <p style="margin:0 0 4px;"><i class="fas fa-hashtag" style="width:14px;"></i> ID: #<?php echo e($category->id); ?></p>
            <p style="margin:0 0 4px;"><i class="fas fa-file-alt" style="width:14px;"></i> Total laporan: <strong><?php echo e($category->reports_count); ?></strong></p>
        </div>

        <div style="display:flex; gap:12px; justify-content:flex-end;">
            <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>"
               style="padding:10px 20px; border:1px solid var(--background-light); border-radius:8px; text-decoration:none; color:var(--text-dark); font-size:0.9em;">
                Batal
            </a>
            <button type="submit"
                    style="background:var(--primary-color); color:#fff; border:none; padding:10px 24px; border-radius:8px; cursor:pointer; font-size:0.9em; font-weight:600;">
                <i class="fas fa-save"></i> Perbarui Kategori
            </button>
        </div>

    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const deptSelect   = document.getElementById('department_id');
    const nameInput    = document.getElementById('name');
    const previewName  = document.getElementById('preview-name');
    const previewBadge = document.getElementById('preview-dept-badge');

    const deptCodes = {};
    Array.from(deptSelect.options).forEach(opt => {
        if (!opt.value) return;
        const match = opt.text.match(/\(([^)]+)\)$/);
        if (match) deptCodes[opt.value] = match[1];
    });

    function updatePreview() {
        previewName.textContent = nameInput.value || 'Nama Kategori';
        const code = deptCodes[deptSelect.value];
        previewBadge.textContent = code || '—';
    }

    nameInput.addEventListener('input', updatePreview);
    deptSelect.addEventListener('change', updatePreview);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.AdminLayout.base_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\development\silapor\resources\views/Admin/Categories/edit.blade.php ENDPATH**/ ?>